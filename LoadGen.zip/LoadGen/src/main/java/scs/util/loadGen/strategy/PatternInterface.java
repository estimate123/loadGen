package scs.util.loadGen.strategy;

public interface PatternInterface {
	public int getIntervalTime();
}
