package scs.util.loadGen.strategy;

public class UniformDistriPattern implements PatternInterface{
	
	@Override
	public int getIntervalTime() {
		// TODO Auto-generated method stub
		return 5;
	}
    
	 
}
